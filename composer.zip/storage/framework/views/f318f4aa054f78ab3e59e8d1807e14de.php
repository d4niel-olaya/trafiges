
<div class="py-4">
    <div class="tab-content" id="tab-ocupantes-anidada">
        <div class="space-y-2">
            <h2 class="text-xl font-semibold text-gray-900">Información de Ocupantes</h2>
            <div class="w-full">
                <div class="border-b border-gray-200">
                    <nav class="flex overflow-x-auto -mb-px space-x-4 sm:space-x-8" aria-label="Tabs">
                        <button id="tab-conductor" class="tab-button-nested py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors duration-200 ease-in-out border-sky-500 text-sky-600" data-target="conductor-content" aria-current="page">Conductor</button>
                        <button id="tab-copiloto" class="tab-button-nested py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors duration-200 ease-in-out border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" data-target="copiloto-content">Copiloto</button>
                        <button id="tab-detras-conductor" class="tab-button-nested py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors duration-200 ease-in-out border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" data-target="detras-conductor-content">Detrás Conductor</button>
                        <button id="tab-detras-copiloto" class="tab-button-nested py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors duration-200 ease-in-out border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" data-target="detras-copiloto-content">Detrás Copiloto</button>
                        <button id="tab-detras-centro" class="tab-button-nested py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors duration-200 ease-in-out border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" data-target="detras-centro-content">Detrás Centro</button>
                        <button id="tab-detras-3" class="tab-button-nested py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors duration-200 ease-in-out border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" data-target="detras-3-content">Detrás 3</button>
                        <button id="tab-detras-4" class="tab-button-nested py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors duration-200 ease-in-out border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" data-target="detras-4-content">Detrás 4</button>
                    </nav>
                </div>

                <div id="conductor-content" class="tab-panel-nested">
                    <div>
                        <?php if (isset($component)) { $__componentOriginal34ef874c7f2252fbbc3db897530f7a64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal34ef874c7f2252fbbc3db897530f7a64 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.formularios.ocupantes','data' => ['ocupante' => 'Conductor','tipo' => 'conductor']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('formularios.ocupantes'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ocupante' => 'Conductor','tipo' => 'conductor']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal34ef874c7f2252fbbc3db897530f7a64)): ?>
<?php $attributes = $__attributesOriginal34ef874c7f2252fbbc3db897530f7a64; ?>
<?php unset($__attributesOriginal34ef874c7f2252fbbc3db897530f7a64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal34ef874c7f2252fbbc3db897530f7a64)): ?>
<?php $component = $__componentOriginal34ef874c7f2252fbbc3db897530f7a64; ?>
<?php unset($__componentOriginal34ef874c7f2252fbbc3db897530f7a64); ?>
<?php endif; ?>
                    </div>
                </div>

                <div id="copiloto-content" class="tab-panel-nested hidden">
                    <div>
                        <?php if (isset($component)) { $__componentOriginal34ef874c7f2252fbbc3db897530f7a64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal34ef874c7f2252fbbc3db897530f7a64 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.formularios.ocupantes','data' => ['ocupante' => 'Copiloto','tipo' => 'copiloto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('formularios.ocupantes'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ocupante' => 'Copiloto','tipo' => 'copiloto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal34ef874c7f2252fbbc3db897530f7a64)): ?>
<?php $attributes = $__attributesOriginal34ef874c7f2252fbbc3db897530f7a64; ?>
<?php unset($__attributesOriginal34ef874c7f2252fbbc3db897530f7a64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal34ef874c7f2252fbbc3db897530f7a64)): ?>
<?php $component = $__componentOriginal34ef874c7f2252fbbc3db897530f7a64; ?>
<?php unset($__componentOriginal34ef874c7f2252fbbc3db897530f7a64); ?>
<?php endif; ?>
                    </div>
                </div>

                <div id="detras-conductor-content" class="tab-panel-nested hidden">
                    <div>
                        <?php if (isset($component)) { $__componentOriginal34ef874c7f2252fbbc3db897530f7a64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal34ef874c7f2252fbbc3db897530f7a64 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.formularios.ocupantes','data' => ['ocupante' => 'Detras Conductor','tipo' => 'detras_conductor']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('formularios.ocupantes'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ocupante' => 'Detras Conductor','tipo' => 'detras_conductor']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal34ef874c7f2252fbbc3db897530f7a64)): ?>
<?php $attributes = $__attributesOriginal34ef874c7f2252fbbc3db897530f7a64; ?>
<?php unset($__attributesOriginal34ef874c7f2252fbbc3db897530f7a64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal34ef874c7f2252fbbc3db897530f7a64)): ?>
<?php $component = $__componentOriginal34ef874c7f2252fbbc3db897530f7a64; ?>
<?php unset($__componentOriginal34ef874c7f2252fbbc3db897530f7a64); ?>
<?php endif; ?>
                    </div>
                </div>

                <div id="detras-copiloto-content" class="tab-panel-nested hidden">
                    <div>
                        <?php if (isset($component)) { $__componentOriginal34ef874c7f2252fbbc3db897530f7a64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal34ef874c7f2252fbbc3db897530f7a64 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.formularios.ocupantes','data' => ['ocupante' => 'Detras Copiloto','tipo' => 'detras_copiloto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('formularios.ocupantes'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ocupante' => 'Detras Copiloto','tipo' => 'detras_copiloto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal34ef874c7f2252fbbc3db897530f7a64)): ?>
<?php $attributes = $__attributesOriginal34ef874c7f2252fbbc3db897530f7a64; ?>
<?php unset($__attributesOriginal34ef874c7f2252fbbc3db897530f7a64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal34ef874c7f2252fbbc3db897530f7a64)): ?>
<?php $component = $__componentOriginal34ef874c7f2252fbbc3db897530f7a64; ?>
<?php unset($__componentOriginal34ef874c7f2252fbbc3db897530f7a64); ?>
<?php endif; ?>
                    </div>
                </div>

                <div id="detras-centro-content" class="tab-panel-nested hidden">
                    <div>
                        <?php if (isset($component)) { $__componentOriginal34ef874c7f2252fbbc3db897530f7a64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal34ef874c7f2252fbbc3db897530f7a64 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.formularios.ocupantes','data' => ['ocupante' => 'Detras Centro','tipo' => 'detras_centro']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('formularios.ocupantes'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ocupante' => 'Detras Centro','tipo' => 'detras_centro']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal34ef874c7f2252fbbc3db897530f7a64)): ?>
<?php $attributes = $__attributesOriginal34ef874c7f2252fbbc3db897530f7a64; ?>
<?php unset($__attributesOriginal34ef874c7f2252fbbc3db897530f7a64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal34ef874c7f2252fbbc3db897530f7a64)): ?>
<?php $component = $__componentOriginal34ef874c7f2252fbbc3db897530f7a64; ?>
<?php unset($__componentOriginal34ef874c7f2252fbbc3db897530f7a64); ?>
<?php endif; ?>
                    </div>
                </div>

                <div id="detras-3-content" class="tab-panel-nested hidden">
                    <div>
                        <?php if (isset($component)) { $__componentOriginal34ef874c7f2252fbbc3db897530f7a64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal34ef874c7f2252fbbc3db897530f7a64 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.formularios.ocupantes','data' => ['ocupante' => 'Detras 3','tipo' => 'detras_3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('formularios.ocupantes'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ocupante' => 'Detras 3','tipo' => 'detras_3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal34ef874c7f2252fbbc3db897530f7a64)): ?>
<?php $attributes = $__attributesOriginal34ef874c7f2252fbbc3db897530f7a64; ?>
<?php unset($__attributesOriginal34ef874c7f2252fbbc3db897530f7a64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal34ef874c7f2252fbbc3db897530f7a64)): ?>
<?php $component = $__componentOriginal34ef874c7f2252fbbc3db897530f7a64; ?>
<?php unset($__componentOriginal34ef874c7f2252fbbc3db897530f7a64); ?>
<?php endif; ?>
                    </div>
                </div>

                <div id="detras-4-content" class="tab-panel-nested hidden">
                    <div>
                        <?php if (isset($component)) { $__componentOriginal34ef874c7f2252fbbc3db897530f7a64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal34ef874c7f2252fbbc3db897530f7a64 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.formularios.ocupantes','data' => ['ocupante' => 'Detras 4','tipo' => 'detras_4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('formularios.ocupantes'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ocupante' => 'Detras 4','tipo' => 'detras_4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal34ef874c7f2252fbbc3db897530f7a64)): ?>
<?php $attributes = $__attributesOriginal34ef874c7f2252fbbc3db897530f7a64; ?>
<?php unset($__attributesOriginal34ef874c7f2252fbbc3db897530f7a64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal34ef874c7f2252fbbc3db897530f7a64)): ?>
<?php $component = $__componentOriginal34ef874c7f2252fbbc3db897530f7a64; ?>
<?php unset($__componentOriginal34ef874c7f2252fbbc3db897530f7a64); ?>
<?php endif; ?>
                    </div>
                </div>
                
            </div> <!-- Cierre w-full -->
        </div> <!-- Cierre space-y-2 -->
    </div> <!-- Cierre tab-content -->
</div> <!-- Cierre py-4 -->
<?php /**PATH C:\Users\jolay\Documents\trafiges\resources\views/components/tab-ocupantes.blade.php ENDPATH**/ ?>