<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['ocupantes_conductor'=> null,'ocupantes_copiloto'=> null, 'ocupantes_detras_conductor'=> null, 'ocupantes_detras_copiloto'=> null, 'ocupantes_detras_centro'=> null, 'ocupantes_detras_3'=> null, 'ocupantes_detras_4'=> null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['ocupantes_conductor'=> null,'ocupantes_copiloto'=> null, 'ocupantes_detras_conductor'=> null, 'ocupantes_detras_copiloto'=> null, 'ocupantes_detras_centro'=> null, 'ocupantes_detras_3'=> null, 'ocupantes_detras_4'=> null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div class="py-4">
    <div class="tab-content" id="tab-ocupantes-anidada">
        <div class="space-y-2">
            <h2 class="text-xl font-semibold text-gray-900">Información de Ocupantes</h2>
            <div class="w-full">
                <div class="border-b border-gray-200">
                    <nav class="flex overflow-x-auto -mb-px space-x-4 sm:space-x-8" aria-label="Tabs">
                        <button id="tab-conductor" class="tab-button-nested py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors duration-200 ease-in-out border-sky-500 text-sky-600" data-target="conductor-content" aria-current="page">Conductor</button>
                        <button id="tab-copiloto" class="tab-button-nested py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors duration-200 ease-in-out border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" data-target="copiloto-content">Copiloto</button>
                        <button id="tab-detras-conductor" class="tab-button-nested py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors duration-200 ease-in-out border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" data-target="detras-conductor-content">Detrás Conductor</button>
                        <button id="tab-detras-copiloto" class="tab-button-nested py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors duration-200 ease-in-out border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" data-target="detras-copiloto-content">Detrás Copiloto</button>
                        <button id="tab-detras-centro" class="tab-button-nested py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors duration-200 ease-in-out border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" data-target="detras-centro-content">Detrás Centro</button>
                        <button id="tab-detras-3" class="tab-button-nested py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors duration-200 ease-in-out border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" data-target="detras-3-content">Detrás 3</button>
                        <button id="tab-detras-4" class="tab-button-nested py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors duration-200 ease-in-out border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" data-target="detras-4-content">Detrás 4</button>
                    </nav>
                </div>

                <div id="conductor-content" class="tab-panel-nested">
                    <div>
                        <?php if (isset($component)) { $__componentOriginal6b2844399df590b3595134019fd1c9ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6b2844399df590b3595134019fd1c9ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.formularios.ocupantes_edit','data' => ['ocupante' => 'Conductor','tipo' => 'conductor','ocupantes' => $ocupantes_conductor]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('formularios.ocupantes_edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ocupante' => 'Conductor','tipo' => 'conductor','ocupantes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ocupantes_conductor)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6b2844399df590b3595134019fd1c9ea)): ?>
<?php $attributes = $__attributesOriginal6b2844399df590b3595134019fd1c9ea; ?>
<?php unset($__attributesOriginal6b2844399df590b3595134019fd1c9ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6b2844399df590b3595134019fd1c9ea)): ?>
<?php $component = $__componentOriginal6b2844399df590b3595134019fd1c9ea; ?>
<?php unset($__componentOriginal6b2844399df590b3595134019fd1c9ea); ?>
<?php endif; ?>
                    </div>
                </div>

                <div id="copiloto-content" class="tab-panel-nested hidden">
                    <div>
                        <?php if (isset($component)) { $__componentOriginal6b2844399df590b3595134019fd1c9ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6b2844399df590b3595134019fd1c9ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.formularios.ocupantes_edit','data' => ['ocupante' => 'Copiloto','tipo' => 'copiloto','ocupantes' => $ocupantes_copiloto]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('formularios.ocupantes_edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ocupante' => 'Copiloto','tipo' => 'copiloto','ocupantes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ocupantes_copiloto)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6b2844399df590b3595134019fd1c9ea)): ?>
<?php $attributes = $__attributesOriginal6b2844399df590b3595134019fd1c9ea; ?>
<?php unset($__attributesOriginal6b2844399df590b3595134019fd1c9ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6b2844399df590b3595134019fd1c9ea)): ?>
<?php $component = $__componentOriginal6b2844399df590b3595134019fd1c9ea; ?>
<?php unset($__componentOriginal6b2844399df590b3595134019fd1c9ea); ?>
<?php endif; ?>
                    </div>
                </div>

                <div id="detras-conductor-content" class="tab-panel-nested hidden">
                    <div>
                        <?php if (isset($component)) { $__componentOriginal6b2844399df590b3595134019fd1c9ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6b2844399df590b3595134019fd1c9ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.formularios.ocupantes_edit','data' => ['ocupante' => 'Detras Conductor','tipo' => 'detras_conductor','ocupantes' => $ocupantes_detras_conductor]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('formularios.ocupantes_edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ocupante' => 'Detras Conductor','tipo' => 'detras_conductor','ocupantes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ocupantes_detras_conductor)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6b2844399df590b3595134019fd1c9ea)): ?>
<?php $attributes = $__attributesOriginal6b2844399df590b3595134019fd1c9ea; ?>
<?php unset($__attributesOriginal6b2844399df590b3595134019fd1c9ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6b2844399df590b3595134019fd1c9ea)): ?>
<?php $component = $__componentOriginal6b2844399df590b3595134019fd1c9ea; ?>
<?php unset($__componentOriginal6b2844399df590b3595134019fd1c9ea); ?>
<?php endif; ?>
                    </div>
                </div>

                <div id="detras-copiloto-content" class="tab-panel-nested hidden">
                    <div>
                        <?php if (isset($component)) { $__componentOriginal6b2844399df590b3595134019fd1c9ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6b2844399df590b3595134019fd1c9ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.formularios.ocupantes_edit','data' => ['ocupante' => 'Detras Copiloto','tipo' => 'detras_copiloto','ocupantes' => $ocupantes_detras_copiloto]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('formularios.ocupantes_edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ocupante' => 'Detras Copiloto','tipo' => 'detras_copiloto','ocupantes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ocupantes_detras_copiloto)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6b2844399df590b3595134019fd1c9ea)): ?>
<?php $attributes = $__attributesOriginal6b2844399df590b3595134019fd1c9ea; ?>
<?php unset($__attributesOriginal6b2844399df590b3595134019fd1c9ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6b2844399df590b3595134019fd1c9ea)): ?>
<?php $component = $__componentOriginal6b2844399df590b3595134019fd1c9ea; ?>
<?php unset($__componentOriginal6b2844399df590b3595134019fd1c9ea); ?>
<?php endif; ?>
                    </div>
                </div>

                <div id="detras-centro-content" class="tab-panel-nested hidden">
                    <div>
                        <?php if (isset($component)) { $__componentOriginal6b2844399df590b3595134019fd1c9ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6b2844399df590b3595134019fd1c9ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.formularios.ocupantes_edit','data' => ['ocupante' => 'Detras Centro','tipo' => 'detras_centro','ocupantes' => $ocupantes_detras_centro]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('formularios.ocupantes_edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ocupante' => 'Detras Centro','tipo' => 'detras_centro','ocupantes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ocupantes_detras_centro)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6b2844399df590b3595134019fd1c9ea)): ?>
<?php $attributes = $__attributesOriginal6b2844399df590b3595134019fd1c9ea; ?>
<?php unset($__attributesOriginal6b2844399df590b3595134019fd1c9ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6b2844399df590b3595134019fd1c9ea)): ?>
<?php $component = $__componentOriginal6b2844399df590b3595134019fd1c9ea; ?>
<?php unset($__componentOriginal6b2844399df590b3595134019fd1c9ea); ?>
<?php endif; ?>
                    </div>
                </div>

                <div id="detras-3-content" class="tab-panel-nested hidden">
                    <div>
                        <?php if (isset($component)) { $__componentOriginal6b2844399df590b3595134019fd1c9ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6b2844399df590b3595134019fd1c9ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.formularios.ocupantes_edit','data' => ['ocupante' => 'Detras 3','tipo' => 'detras_3','ocupantes' => $ocupantes_detras_3]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('formularios.ocupantes_edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ocupante' => 'Detras 3','tipo' => 'detras_3','ocupantes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ocupantes_detras_3)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6b2844399df590b3595134019fd1c9ea)): ?>
<?php $attributes = $__attributesOriginal6b2844399df590b3595134019fd1c9ea; ?>
<?php unset($__attributesOriginal6b2844399df590b3595134019fd1c9ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6b2844399df590b3595134019fd1c9ea)): ?>
<?php $component = $__componentOriginal6b2844399df590b3595134019fd1c9ea; ?>
<?php unset($__componentOriginal6b2844399df590b3595134019fd1c9ea); ?>
<?php endif; ?>
                    </div>
                </div>

                <div id="detras-4-content" class="tab-panel-nested hidden">
                    <div>
                        <?php if (isset($component)) { $__componentOriginal6b2844399df590b3595134019fd1c9ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6b2844399df590b3595134019fd1c9ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.formularios.ocupantes_edit','data' => ['ocupante' => 'Detras 4','tipo' => 'detras_4','ocupantes' => $ocupantes_detras_4]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('formularios.ocupantes_edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ocupante' => 'Detras 4','tipo' => 'detras_4','ocupantes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ocupantes_detras_4)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6b2844399df590b3595134019fd1c9ea)): ?>
<?php $attributes = $__attributesOriginal6b2844399df590b3595134019fd1c9ea; ?>
<?php unset($__attributesOriginal6b2844399df590b3595134019fd1c9ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6b2844399df590b3595134019fd1c9ea)): ?>
<?php $component = $__componentOriginal6b2844399df590b3595134019fd1c9ea; ?>
<?php unset($__componentOriginal6b2844399df590b3595134019fd1c9ea); ?>
<?php endif; ?>
                    </div>
                </div>
                
            </div> <!-- Cierre w-full -->
        </div> <!-- Cierre space-y-2 -->
    </div> <!-- Cierre tab-content -->
</div> <!-- Cierre py-4 -->
<?php /**PATH C:\Users\jolay\Documents\trafiges\resources\views/components/tab-ocupantes_edit.blade.php ENDPATH**/ ?>