<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'hiddenId' => 'hidden-input',
    'inputId' => 'autocomplete-input',
    'inputName' => 'autocomplete-name',
    'suggestionsId' => 'suggestions-list',
    'hiddenName' => 'hidden_value',
    'placeholder' => 'Buscar...',
    'containerClass' => 'relative',
    'inputClass' => 'w-full border rounded px-4 py-2 focus:outline-none focus:ring focus:border-blue-300',
    'suggestionsClass' => 'absolute bg-white border border-gray-300 w-full rounded shadow-lg mt-1 hidden max-h-48 overflow-y-auto z-50',
    'hiddenValue' => '',
    'inputValue' => '',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'hiddenId' => 'hidden-input',
    'inputId' => 'autocomplete-input',
    'inputName' => 'autocomplete-name',
    'suggestionsId' => 'suggestions-list',
    'hiddenName' => 'hidden_value',
    'placeholder' => 'Buscar...',
    'containerClass' => 'relative',
    'inputClass' => 'w-full border rounded px-4 py-2 focus:outline-none focus:ring focus:border-blue-300',
    'suggestionsClass' => 'absolute bg-white border border-gray-300 w-full rounded shadow-lg mt-1 hidden max-h-48 overflow-y-auto z-50',
    'hiddenValue' => '',
    'inputValue' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div <?php echo e($attributes->merge(['class' => $containerClass])); ?>>
    <input
        type="hidden"
        id="<?php echo e($hiddenId); ?>"
        name="<?php echo e($hiddenName); ?>"
        value="<?php echo e($hiddenValue); ?>"
    />
    <input
        type="text"
        id="<?php echo e($inputId); ?>"
        placeholder="<?php echo e($placeholder); ?>"
        class="<?php echo e($inputClass); ?>"
        name="<?php echo e($inputName); ?>"
        value="<?php echo e($inputValue); ?>"
        autocomplete="off"
    />
    <ul
        id="<?php echo e($suggestionsId); ?>"
        class="<?php echo e($suggestionsClass); ?>"
    ></ul>
</div>
<?php /**PATH C:\Users\jolay\Documents\trafiges\resources\views/components/utilidades/autocomplete.blade.php ENDPATH**/ ?>